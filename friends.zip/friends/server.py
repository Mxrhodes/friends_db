from flask import Flask, render_template, redirect, request, flash, session
from mysqlconnection import MySQLConnector


app = Flask(__name__)
app.secret_key = "TODAY"
mysql = MySQLConnector(app, 'friends')

@app.route("/")
def index():
	friends = mysql.query_db("SELECT * FROM friends;")
	return render_template("index.html", friends = friends)

@app.route("/add", methods=["POST"])
def add():
	print(request.form)
	query = "INSERT INTO friends(name, age, created_at) VALUES(:name, :age, NOW());"
	mysql.query_db(query, request.form)
	return redirect("/")

app.run(debug=True)